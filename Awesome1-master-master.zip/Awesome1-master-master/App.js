import React from 'react'

import Router from './routes/drawer'

export default function App() {
  return (
    <Router/>
  )
}
